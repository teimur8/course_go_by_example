package shapes1

import "fmt"

// SquareArea ... your comments
func SquareArea(s int) int {
	return s * s
}

func init() {
	fmt.Println("=> init() from shapes1.square package.")
}
