// File name: ...\s02\01_helloworld\main.go
// Course Name: Go (Golang) Programming by Example (by Kam Hojati)

// I am a line comment!

/*  I am a
multi-line
comment!
I'm being ignored by
the compiler :(
*/

package main

import "fmt"

func main() {
	fmt.Println("Hello World")
}
